# Testing

This directory contains both unittest and manual testing scripts. Ideally, everything will be unit tested or integration tested, but it's research so understandably there may be some manual test scripts for simplicity and speed. If you see something you don't like, feel free to open an issue or a pull request to add more formal testing! It would be much appreciated!!! (And you'd be added to the list of contributors)
